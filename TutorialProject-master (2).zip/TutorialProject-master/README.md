# TutorialProject
1. Our website has been created to provide chinese teachings for those who need it 
<br>
2. We I'll provide lessons that involves depicting writing, colors and comparing. 
<br>
3. There will also be quizzes created to help test that the student is fully trained to speak chinese 
<br>
